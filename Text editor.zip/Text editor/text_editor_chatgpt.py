import tkinter as tk
from tkinter import filedialog
import os

class TextEditorApp:
    def __init__(self, master):
        self.master = master
        master.title("Raouf's Text Editor")

        self.filepath = None
        self.text_stack = []
        self.current_filename = "Main Text Area"

        self.create_widgets()

    def create_widgets(self):
        self.master.rowconfigure(0, minsize=600)
        self.master.columnconfigure(1, minsize=800)

        self.txt_edit = tk.Text(self.master, height=10, width=50)
        self.txt_edit.grid(column=1, row=0, sticky="news")

        self.frame_btn = tk.Frame(self.master, bd=2, width=200, height=200)
        self.frame_btn.grid(column=0, row=0, sticky="w")

        self.btn_newfile = tk.Button(self.frame_btn, text="New file", fg="#FF8E00", background="white", width=10, command=self.new_file)
        self.btn_open = tk.Button(self.frame_btn, text="Open file", fg="blue", background="Lightblue", width=10, command=self.open_file)
        self.btn_reset = tk.Button(self.frame_btn, text="Reset text", fg="Black", background="tomato", width=10, command=self.reset)
        self.btn_save = tk.Button(self.frame_btn, text="Save file", fg="Black", background="lemon chiffon", width=10, command=self.save_file)
        self.btn_undo = tk.Button(self.frame_btn, text="Undo", fg="Black", background="cyan", width=10, command=self.undo)

        self.btn_newfile.grid(column=0, row=0, sticky="n", pady=6)
        self.btn_open.grid(column=0, row=1, sticky="n", pady=6)
        self.btn_reset.grid(column=0, row=2, sticky="n", pady=6)
        self.btn_save.grid(column=0, row=3, sticky="n", pady=6)
        self.btn_undo.grid(column=0, row=4, sticky="n", pady=6)

        self.master.bind("<KeyRelease>", self.track_changes)

        self.lbl_filename = tk.Label(self.master, text=f"Current File: {self.current_filename}", font=("Arial", 12), background="lightblue")
        self.lbl_filename.grid()

    def update_filename(self):
        self.lbl_filename.config(text=f"Current File: {os.path.basename(self.current_filename)}")

    def track_changes(self, event=None):
        current_content = str(self.txt_edit.get("1.0", tk.END))
        self.text_stack.append(current_content)
        self.update_filename()

    def open_file(self):
        self.filepath = filedialog.askopenfilename(defaultextension=".txt",
                                                    filetypes=[
                                                        ("Text file", ".txt"),
                                                        ("HTML file", ".html"),
                                                        ("All files", "*.*")]
                                                    )
        if self.filepath:
            with open(self.filepath, "r") as file:
                self.txt_edit.delete("1.0", tk.END)
                self.txt_edit.insert(tk.END, file.read())
                self.text_stack.clear()
                self.current_filename = self.filepath
                self.update_filename()

    def new_file(self):
        self.filepath = filedialog.asksaveasfilename(defaultextension=".txt",
                                                      filetypes=[
                                                          ("Text file", ".txt"),
                                                          ("HTML file", ".html"),
                                                          ("All files", "*.*")]
                                                      )
        if self.filepath:
            with open(self.filepath, "w"):
                pass  # Create an empty file
            self.txt_edit.delete("1.0", tk.END)
            self.text_stack.clear()
            self.current_filename = self.filepath
            self.update_filename()

    def save_file(self):
        if self.filepath:
            file_content = str(self.txt_edit.get("1.0", tk.END))
            with open(self.filepath, "w") as file:
                file.write(file_content)
            self.update_filename()

    def reset(self):
        self.txt_edit.delete("1.0", tk.END)
        self.text_stack.clear()
        self.current_filename = "Main Text Area"
        self.update_filename()

    def undo(self):
        if self.text_stack:
            undo_data = self.text_stack.pop()
            self.txt_edit.delete("1.0", tk.END)
            self.txt_edit.insert(tk.END, undo_data)
        self.update_filename()

if __name__ == "__main__":
    root = tk.Tk()
    app = TextEditorApp(root)
    root.mainloop()
