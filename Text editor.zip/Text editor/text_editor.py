import tkinter as tk
from tkinter import filedialog
import os

#global vars
filepath = None
text_stack =[]
current_filename = "Main Text Area"

def update_filename():
    lbl_filename.config(text=f"Current File: {os.path.basename(current_filename)}")


def track_changes(event = None):
    current_content = str(txt_edit.get("1.0", tk.END))
    text_stack.append(current_content)
    update_filename()


def Openfile():
    global filepath, current_filename
    filepath = filedialog.askopenfilename(defaultextension= ".txt",
                                          filetypes=[
                                              ("Text file", ".txt"),
                                              ("html file", ".html"),
                                              ("All files" "*.")]
                                          )
    if filepath:
        file = open(filepath, "r")
        txt_edit.delete("1.0", tk.END)
        txt_edit.insert(tk.END, file.read())
        text_stack.clear()
        file.close()
        current_filename = filepath
        update_filename()

def Newfile():
    global filepath, current_filename
    filepath = filedialog.asksaveasfilename(defaultextension= ".txt",
                                          filetypes=[
                                              ("Text file", ".txt"),
                                              ("html file", ".html"),
                                              ("All files" "*.*")]
                                            )
    if filepath:
        file = open(filepath, "w")
        txt_edit.delete("1.0",tk.END)
        text_stack.clear()
        file.close()
        current_filename = filepath
        update_filename()

def Savefile():
    global filepath, current_filename
    if filepath:
        file_content = str(txt_edit.get("1.0",tk.END))
        file = open(filepath, "w")
        file.write(file_content)
        file.close()
        update_filename()

def Reset():
    global current_filename
    txt_edit.delete("1.0",tk.END)
    text_stack.clear()
    current_filename = "Main Text Area"
    update_filename()

def Undo():
    if text_stack:
        undo_data = text_stack.pop()
        txt_edit.delete("1.0", tk.END)
        txt_edit.insert(tk.END, undo_data)
    update_filename()

window = tk.Tk()
window.title("Raouf's text iditor")

window.rowconfigure(0, minsize=600)
window.columnconfigure(1, minsize=800)

txt_edit = tk.Text(window, height=10, width=50)
txt_edit.grid(column=1, row=0,sticky="news")


frame_btn = tk.Frame(window, bd=2, width=200, height=200)
frame_btn.grid(column=0, row=0, sticky="w")

btn_newfile = tk.Button(frame_btn, text= "New file", fg="#FF8E00", background="white", width=10, command= Newfile)
btn_open = tk.Button(frame_btn, text="Open file", fg="blue", background="Lightblue", width=10, command= Openfile)
btn_reset = tk.Button(frame_btn, text="Reset text", fg="Black", background="tomato", width=10, command= Reset)
btn_save = tk.Button(frame_btn, text="Save file", fg="Black", background="lemon chiffon", width=10, command= Savefile)
btn_undo = tk.Button(frame_btn, text="Undo", fg="Black", background="cyan", width=10, command= Undo)

btn_newfile.grid(column=0, row=0, sticky= "n", pady=6)
btn_open.grid(column= 0, row= 1,sticky ="n", pady=6)
btn_reset.grid(column= 0, row= 2, sticky ="n", pady=6)
btn_save.grid(column= 0, row= 3, sticky ="n", pady=6)
btn_undo.grid(column= 0, row= 4, sticky ="n", pady=6)

window.bind("<KeyRelease>", track_changes)

#label to display the name of the current file
lbl_filename = tk.Label(window, text=f"Current File: {current_filename}", font=("Arial", 12),background="lightblue")
lbl_filename.grid()

window.mainloop()