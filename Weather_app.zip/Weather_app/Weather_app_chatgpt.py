import tkinter as tk
from tkinter import messagebox
from threading import Thread
import requests

class WeatherApp:
    def __init__(self, master):
        self.master = master
        master.title("Weather App")
        master.minsize(width=450, height=300)

        self.create_widgets()

    def create_widgets(self):
        self.lbl_location = tk.Label(self.master, text="Location:", font=1, padx=50)
        self.lbl_location.grid(column=0, row=0)

        self.lbl_frame = tk.Frame(self.master, height=300, width=200)
        self.lbl_frame.grid()

        self.lbl_Temp = tk.Label(self.lbl_frame, text="Temperature:", fg="black", font=0, padx=50)
        self.lbl_humidity = tk.Label(self.lbl_frame, text="Humidity:", fg="black", font=0, padx=50)
        self.lbl_wind_SP = tk.Label(self.lbl_frame, text="Wind Speed:", fg="black", font=0, padx=50)
        self.lbl_pressure = tk.Label(self.lbl_frame, text="Pressure:", fg="black", font=0, padx=50)
        self.lbl_prec = tk.Label(self.lbl_frame, text="Precipitation:", fg="black", font=0, padx=50)

        self.lbl_Temp.grid(column=0, row=1, pady=9, padx=6)
        self.lbl_humidity.grid(column=0, row=2, pady=9, padx=6)
        self.lbl_wind_SP.grid(column=0, row=3, pady=9, padx=6)
        self.lbl_pressure.grid(column=0, row=4, pady=9, padx=6)
        self.lbl_prec.grid(column=0, row=5, pady=9, padx=6)

        self.entry_location = tk.Entry(self.master, width=18)
        self.entry_location.grid(column=2, row=0, padx=10, pady=20)

        self.btn_Search = tk.Button(self.master, text="Search", command=self.search_btn)
        self.btn_Search.grid(row=0, column=3, padx=60, pady=20, sticky="ne")

    def search_btn(self):
        entered_text = self.entry_location.get().strip()
        if not entered_text:
            messagebox.showerror("Error", "Please enter a location")
            return

        # Run API request in a separate thread
        Thread(target=self.get_weather_data, args=(entered_text,), daemon=True).start()

    def get_weather_data(self, city):
        api_key = 'b0b165fb23537a7711966f63d09c4a1e'
        url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            self.update_labels(data)
        except requests.exceptions.RequestException as e:
            if isinstance(e, requests.exceptions.HTTPError) and e.response.status_code == 404:
                messagebox.showerror("Error", f"Location '{city}' not found.")
            else:
                messagebox.showerror("Error", f"Error: {e}")

    def update_labels(self, data):
        temperature = data['main']['temp']
        humidity = data['main']['humidity']
        wind_speed = data['wind']['speed']
        pressure = data['main']['pressure']
        rain_data = data.get('rain', {})
        precipitation_last_hour = rain_data.get('1h', 0)

        self.lbl_Temp.config(text=f"Temperature: {int(temperature - 273.15)}°C")
        self.lbl_humidity.config(text=f"Humidity: {humidity}%")
        self.lbl_wind_SP.config(text=f"Wind Speed: {wind_speed}km/h")
        self.lbl_pressure.config(text=f"Pressure: {pressure}hPa")
        self.lbl_prec.config(text=f"Precipitation: {precipitation_last_hour}%")

if __name__ == "__main__":
    root = tk.Tk()
    app = WeatherApp(root)
    root.mainloop()
