import random

def get_user_input():
    while True:
        try:
            user_input = int(input("Enter a number between 0 and 10 (or 99 to exit): "))
            if user_input == 99:
                exit_game()
            elif 0 <= user_input <= 10:
                return user_input
            else:
                print("Invalid input. Please enter a number between 0 and 10.")
        except ValueError:
            print("Invalid input. Please enter a valid integer.")

def exit_game():
    print("Thanks for playing! Exiting the game.")
    exit()

def main():
    print("Welcome to the Number Guessing Game!")
    print("Considerations:")
    print("- Enter a valid integer between 0 and 10.")
    print("- Type 99 at any time to exit the game.")
    
    score = 0
    
    while True:
        start_game = input("Start a new game? (Enter 1 for Yes, any other key to exit): ")
        
        if start_game != "1":
            exit_game()

        generated_num = random.randint(0, 10)
        score = play_game(generated_num, score)

def play_game(generated_num, score):
    print("New game started! Try to guess the number.")

    while True:
        user_input = get_user_input()

        if user_input == generated_num:
            score += 1
            print(f"Congratulations! You guessed the number in {score} attempts.")
            return score
        elif user_input < generated_num:
            score += 1
            print("Go higher.")
        elif user_input > generated_num:
            score += 1
            print("Go lower.")

if __name__ == "__main__":
    main()
